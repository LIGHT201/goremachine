document.addEventListener("DOMContentLoaded", function() {
    // 1. Inject the CSS Animation into the <head>
    const style = document.createElement('style');
    style.textContent = `
        @keyframes scrollScanlines {
            from { background-position: 0 0; }
            to { background-position: 0 100%; }
        }
    `;
    document.head.appendChild(style);

    const overlay = document.createElement('div');
    
    // Base container styling
    Object.assign(overlay.style, {
        position: 'fixed',
        top: '0',
        left: '0',
        width: '100vw',
        height: '100vh',
        pointerEvents: 'none',
        zIndex: '9999'
    });

    overlay.innerHTML = `
        <div style="
            position: absolute;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: linear-gradient(
                rgba(18, 16, 16, 0) 50%, 
                rgba(0, 0, 0, 0.15) 50%
            );
            background-size: 100% 8px; 
            z-index: 10;
            /* 2. Apply the animation here */
            animation: scrollScanlines 20s linear infinite;
        "></div>
    `;

    document.body.appendChild(overlay);
});