function updateGMT() {
    const now = new Date();
    
    // Get UTC (GMT) parts
    const h = String(now.getUTCHours()).padStart(2, '0');
    const m = String(now.getUTCMinutes()).padStart(2, '0');
    const s = String(now.getUTCSeconds()).padStart(2, '0');

    // Update the <p> tag
    const display = document.getElementById('time');
    if (display) {
        display.textContent = `Current Time: ${h}:${m}:${s} GMT`;
    }
}

// Update immediately and then every second
updateGMT();
setInterval(updateGMT, 1000);