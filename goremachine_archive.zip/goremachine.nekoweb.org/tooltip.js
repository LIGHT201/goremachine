const tooltip = document.createElement('div');
tooltip.className = 'tooltip';
document.body.appendChild(tooltip);

document.querySelectorAll('[data-tooltip]').forEach(element => {
    element.addEventListener('mouseenter', (e) => {
        const target = e.target.closest('[data-tooltip]');
        if (!target) return;

        let rawText = target.getAttribute('data-tooltip');
        
        // 1. Process <w> (Wavy)
        let processedText = rawText.replace(/<w>(.*?)<\/w>/g, (match, content) => {
            return content.split('').map((char, i) => 
                `<span class="wavy" style="--i:${i}">${char === ' ' ? '&nbsp;' : char}</span>`
            ).join('');
        });

        // 2. Process <sh> (Shake)
        processedText = processedText.replace(/<sh>(.*?)<\/sh>/g, (match, content) => {
            return content.split('').map((char, i) => 
                `<span class="shake" style="--i:${i}">${char === ' ' ? '&nbsp;' : char}</span>`
            ).join('');
        });

        tooltip.innerHTML = processedText;
        tooltip.style.display = 'block';
    });

    element.addEventListener('mousemove', (e) => {
        tooltip.style.left = e.clientX + 15 + 'px';
        tooltip.style.top = e.clientY + 15 + 'px';
    });

    element.addEventListener('mouseleave', () => {
        tooltip.style.display = 'none';
        tooltip.innerHTML = ''; 
    });
});