function updateGoreTime() {
    const now = new Date();
    const elements = document.querySelectorAll('.time-ago');

    elements.forEach(el => {
        const dateAttr = el.getAttribute('data-date');
        const postDate = new Date(dateAttr.replace(/-/g, "/"));
        const diffInSeconds = Math.floor((now - postDate) / 1000);

        // 1. Calculate "Time Ago"
        let timeAgoText = "JUST NOW";
        const units = [
            { label: 'YEAR', seconds: 31536000 },
            { label: 'MONTH', seconds: 2592000 },
            { label: 'WEEK', seconds: 604800 },
            { label: 'DAY', seconds: 86400 },
            { label: 'HOUR', seconds: 3600 },
            { label: 'MINUTE', seconds: 60 }
        ];

        if (diffInSeconds > 0) {
            for (const unit of units) {
                const interval = Math.floor(diffInSeconds / unit.seconds);
                if (interval >= 1) {
                    timeAgoText = `${interval} ${unit.label}${interval > 1 ? 'S' : ''} AGO`;
                    break;
                }
            }
        }

        // 2. Format the Automatic Static Date
        const dateOptions = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        };
        const fullDate = postDate.toLocaleDateString('en-US', dateOptions);

        // 3. Inject both into the HTML with a line break
        el.innerHTML = `
            <span class="relative-time" style="display:block; color:#ff0000; font-weight:bold;">${timeAgoText}</span>
            <span class="actual-date" style="display:block; color:#ff0000; font-size:0.75rem; font-family:monospace;">[ LOGGED: ${fullDate.toUpperCase()} ]</span>
        `;
    });
}

setInterval(updateGoreTime, 1000);
updateGoreTime();