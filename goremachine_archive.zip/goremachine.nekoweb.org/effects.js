document.addEventListener("DOMContentLoaded", () => {
    const effectElements = document.querySelectorAll('[class*="effect-"]');

    effectElements.forEach(el => {
        // --- STEP 1: Text Transformations (Quirks) ---
        if (el.classList.contains('effect-quirk')) {
            el.innerText = el.innerText.toLowerCase()
                .replace(/a/g, '4')
                .replace(/o/g, '_')
                .replace(/e/g, '3')
                .replace(/l/g, '1');
        }

        // --- STEP 2: Character-based Animations ---
        const needsSpans = el.classList.contains('effect-shake') || el.classList.contains('effect-wavy');
        
        if (needsSpans) {
            const classes = [];
            if (el.classList.contains('effect-shake')) classes.push('shake');
            if (el.classList.contains('effect-wavy')) classes.push('wavy');

            // Grab custom settings from data attributes (or use defaults)
            const intensity = el.getAttribute('data-intensity') || '1px';
            const speed = el.getAttribute('data-speed') || '0.15s';

            const text = el.innerText;
            el.innerHTML = text.split('').map((char, i) => {
                const displayChar = char === ' ' ? '&nbsp;' : char;
                // Pass the intensity and speed into each span's style
                return `<span class="${classes.join(' ')}" style="--i:${i}; --intensity:${intensity}; --speed:${speed}">${displayChar}</span>`;
            }).join('');
        }

        // --- STEP 3: Box Transformations ---
        if (el.classList.contains('effect-reversed')) {
            el.style.display = "inline-block";
            el.style.transform = (el.style.transform || "") + " scaleX(-1)";
        }
    });
});